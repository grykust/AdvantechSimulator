Advantech WISE-4000 REST API Simulator
Run with: ./AdvantechSimulator
Use Railway with Dockerfile
